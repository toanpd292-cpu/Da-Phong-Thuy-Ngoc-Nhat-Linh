import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Diamond, Search, Menu, X, Phone, MessageCircle, ChevronRight, Facebook } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);
  const [isSearchOpen, setIsSearchOpen] = React.useState(false);
  const [searchQuery, setSearchQuery] = React.useState('');
  const navigate = useNavigate();
  const location = useLocation();

  // Lock body scroll when mobile menu is open
  React.useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Close menu and search on route change
  React.useEffect(() => {
    setIsOpen(false);
    setIsSearchOpen(false);
  }, [location.pathname]);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
    if (isSearchOpen) setIsSearchOpen(false);
  };

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
    if (isOpen) setIsOpen(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  const navLinks = [
    { name: 'Trang chủ', href: '/' },
    { name: 'Cửa hàng', href: '/products' },
    { name: 'Tư vấn', href: '/destiny' },
    { name: 'Blog', href: '/blog' },
    { name: 'Về chúng tôi', href: '/about' },
    { name: 'Liên hệ', href: '/contact' },
  ];

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-slate-100 bg-white/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-10">
            <Link to="/" className="flex items-center gap-2 group">
              <Diamond className="text-primary w-8 h-8 group-hover:rotate-12 transition-transform" />
              <h1 className="font-serif text-xl font-bold tracking-tight text-charcoal">NGỌC NHẤT LINH</h1>
            </Link>
            
            <nav className="hidden md:flex items-center gap-8 text-sm font-medium uppercase tracking-widest text-slate-600">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  className={cn(
                    "hover-gold transition-all relative py-1",
                    location.pathname === link.href && "text-primary after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-full after:h-0.5 after:bg-primary"
                  )}
                >
                  {link.name}
                </Link>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-6">
            <form onSubmit={handleSearch} className="relative hidden lg:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-10 w-64 rounded-full border-slate-200 bg-slate-50 pl-10 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                placeholder="Tìm kiếm sản phẩm..."
              />
            </form>
            
            <div className="flex items-center gap-2 md:gap-4">
              <button 
                className="lg:hidden p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-600"
                onClick={toggleSearch}
                aria-label="Tìm kiếm"
              >
                <Search className="w-5 h-5" />
              </button>
              <a 
                href="https://www.facebook.com/profile.php?id=61575224635423" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hidden md:flex items-center gap-2 bg-[#1877F2] text-white px-4 py-2 text-xs font-bold uppercase tracking-widest hover:bg-[#166fe5] transition-all rounded-sm shadow-sm hover:shadow-md"
              >
                <Facebook className="w-4 h-4" />
                Fanpage
              </a>
              <Link to="/contact" className="hidden md:block bg-primary text-white px-6 py-2 text-xs font-bold uppercase tracking-widest hover:bg-primary-dark transition-all rounded-sm shadow-sm hover:shadow-md">
                Liên hệ
              </Link>
              <button 
                className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
                onClick={toggleMenu}
                aria-label={isOpen ? "Đóng menu" : "Mở menu"}
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

      </header>

      {/* Mobile Search Bar */}
      <AnimatePresence>
        {isSearchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed top-[72px] left-0 right-0 z-[60] px-6 py-4 bg-white border-b border-slate-100 lg:hidden shadow-lg"
          >
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-12 w-full rounded-xl border-slate-200 bg-slate-50 pl-10 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                placeholder="Tìm kiếm sản phẩm..."
              />
              <button 
                type="button"
                onClick={() => setIsSearchOpen(false)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-slate-100 rounded-full transition-colors"
                aria-label="Đóng tìm kiếm"
              >
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] md:hidden"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-[85%] max-w-sm bg-white z-[70] md:hidden shadow-2xl flex flex-col overflow-hidden"
            >
              <div className="flex items-center justify-between p-6 border-b border-slate-100 flex-shrink-0">
                <span className="font-serif font-bold text-primary tracking-widest">MENU</span>
                <button 
                  onClick={() => setIsOpen(false)} 
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                  aria-label="Đóng menu"
                >
                  <X className="w-6 h-6 text-slate-600" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto overscroll-contain">
                <div className="flex flex-col p-8 gap-6">
                  {navLinks.map((link, i) => (
                    <motion.div
                      key={link.href}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <Link
                        to={link.href}
                        className={cn(
                          "text-lg font-medium uppercase tracking-[0.2em] text-slate-600 hover:text-primary transition-colors flex items-center justify-between group py-2",
                          location.pathname === link.href && "text-primary font-bold"
                        )}
                      >
                        {link.name}
                        <ChevronRight className={cn("w-5 h-5 opacity-0 -translate-x-2 transition-all group-hover:opacity-100 group-hover:translate-x-0", location.pathname === link.href && "opacity-100 translate-x-0")} />
                      </Link>
                    </motion.div>
                  ))}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: navLinks.length * 0.05 }}
                    className="mt-4"
                  >
                    <Link 
                      to="/contact"
                      className="w-full bg-primary text-white py-4 rounded-xl font-bold uppercase tracking-widest text-center shadow-lg shadow-primary/20 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
                    >
                      Liên hệ ngay
                    </Link>
                  </motion.div>
                </div>
              </div>
              
              <div className="p-8 bg-slate-50 border-t border-slate-100">
                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4">Kết nối với chúng tôi</p>
                <div className="flex gap-4">
                  <a href="tel:0902111626" className="size-10 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-600 hover:text-primary transition-colors">
                    <Phone className="w-5 h-5" />
                  </a>
                  <a href="https://www.facebook.com/profile.php?id=61575224635423" target="_blank" rel="noopener noreferrer" className="size-10 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-600 hover:text-primary transition-colors">
                    <Facebook className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
        <motion.a
          href="https://zalo.me/0902111626"
          target="_blank"
          rel="noreferrer"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="bg-[#0068ff] text-white p-4 rounded-full shadow-lg hover:shadow-blue-400/40 transition-all flex items-center justify-center"
          title="Tư vấn Zalo"
        >
          <MessageCircle className="w-6 h-6" />
        </motion.a>
        <motion.a
          href="https://www.facebook.com/profile.php?id=61575224635423"
          target="_blank"
          rel="noreferrer"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="bg-[#1877F2] text-white p-4 rounded-full shadow-lg hover:shadow-blue-500/40 transition-all flex items-center justify-center"
          title="Tư vấn Facebook"
        >
          <Facebook className="w-6 h-6" />
        </motion.a>
        <motion.a
          href="tel:0902111626"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="bg-primary text-white p-4 rounded-full shadow-lg hover:shadow-primary/40 transition-all flex items-center justify-center"
          title="Gọi ngay"
        >
          <Phone className="w-6 h-6" />
        </motion.a>
      </div>
    </>
  );
}
