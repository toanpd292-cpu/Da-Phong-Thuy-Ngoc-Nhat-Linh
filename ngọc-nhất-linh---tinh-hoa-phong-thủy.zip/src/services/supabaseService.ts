import { supabase } from '../lib/supabase';
import { Product } from '../data/products';

export interface Blog {
  id?: number;
  title: string;
  content: string;
  author: string;
  date: string;
  image: string;
  category: string;
  excerpt: string;
}

export interface Customer {
  id?: number;
  name: string;
  email: string;
  phone: string;
  address: string;
  notes: string;
  created_at?: string;
}

export interface CampaignImage {
  id?: number;
  url: string;
  title: string;
  subtitle: string;
  active: boolean;
}

export const supabaseService = {
  // Products
  async getProducts(): Promise<Product[]> {
    const { data, error } = await supabase.from('products').select('*');
    if (error) throw error;
    return data as Product[];
  },
  async addProduct(product: Omit<Product, 'id'>) {
    const { data, error } = await supabase.from('products').insert([product]).select();
    if (error) throw error;
    return data[0];
  },
  async updateProduct(id: number, product: Partial<Product>) {
    const { data, error } = await supabase.from('products').update(product).eq('id', id).select();
    if (error) throw error;
    return data[0];
  },
  async deleteProduct(id: number) {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) throw error;
  },

  // Blogs
  async getBlogs(): Promise<Blog[]> {
    const { data, error } = await supabase.from('blogs').select('*').order('date', { ascending: false });
    if (error) throw error;
    return data as Blog[];
  },
  async addBlog(blog: Omit<Blog, 'id'>) {
    const { data, error } = await supabase.from('blogs').insert([blog]).select();
    if (error) throw error;
    return data[0];
  },
  async updateBlog(id: number, blog: Partial<Blog>) {
    const { data, error } = await supabase.from('blogs').update(blog).eq('id', id).select();
    if (error) throw error;
    return data[0];
  },
  async deleteBlog(id: number) {
    const { error } = await supabase.from('blogs').delete().eq('id', id);
    if (error) throw error;
  },

  // Customers
  async getCustomers(): Promise<Customer[]> {
    const { data, error } = await supabase.from('customers').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data as Customer[];
  },
  async addCustomer(customer: Omit<Customer, 'id'>) {
    const { data, error } = await supabase.from('customers').insert([customer]).select();
    if (error) throw error;
    return data[0];
  },

  // Campaign Images
  async getCampaignImages(): Promise<CampaignImage[]> {
    const { data, error } = await supabase.from('campaign_images').select('*').eq('active', true);
    if (error) throw error;
    return data as CampaignImage[];
  },
  async getAllCampaignImages(): Promise<CampaignImage[]> {
    const { data, error } = await supabase.from('campaign_images').select('*');
    if (error) throw error;
    return data as CampaignImage[];
  },
  async addCampaignImage(image: Omit<CampaignImage, 'id'>) {
    const { data, error } = await supabase.from('campaign_images').insert([image]).select();
    if (error) throw error;
    return data[0];
  },
  async updateCampaignImage(id: number, image: Partial<CampaignImage>) {
    const { data, error } = await supabase.from('campaign_images').update(image).eq('id', id).select();
    if (error) throw error;
    return data[0];
  },
  async deleteCampaignImage(id: number) {
    const { error } = await supabase.from('campaign_images').delete().eq('id', id);
    if (error) throw error;
  },

  // Newsletter
  async subscribeNewsletter(email: string) {
    const { data, error } = await supabase.from('newsletter_subscriptions').insert([{ email }]).select();
    if (error) throw error;
    return data[0];
  }
};
