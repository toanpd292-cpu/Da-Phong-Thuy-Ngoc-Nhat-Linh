import { supabase } from '../lib/supabase';
import { products as mockProducts, Product } from '../data/products';

export const productService = {
  async getAllProducts(): Promise<Product[]> {
    try {
      if (!supabase) {
        console.warn('Supabase client not initialized, using mock data.');
        return mockProducts;
      }

      const { data, error } = await supabase
        .from('products')
        .select('*');

      if (error) {
        console.error('Error fetching products from Supabase:', error);
        return mockProducts; // Fallback to mock data
      }

      if (!data || data.length === 0) {
        return mockProducts; // Fallback to mock data if table is empty
      }

      // Map Supabase data to Product interface if needed
      return data as Product[];
    } catch (err) {
      console.error('Unexpected error fetching products:', err);
      return mockProducts;
    }
  },

  async getProductById(id: number): Promise<Product | undefined> {
    try {
      if (!supabase) {
        console.warn('Supabase client not initialized, using mock data.');
        return mockProducts.find(p => p.id === id);
      }

      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        console.error(`Error fetching product ${id} from Supabase:`, error);
        return mockProducts.find(p => p.id === id);
      }

      return data as Product;
    } catch (err) {
      console.error(`Unexpected error fetching product ${id}:`, err);
      return mockProducts.find(p => p.id === id);
    }
  }
};
