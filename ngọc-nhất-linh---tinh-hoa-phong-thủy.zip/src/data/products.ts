export interface Product {
  id: number;
  name: string;
  price: string;
  oldPrice?: string;
  tag: string;
  img: string;
  description: string;
  category: string;
  affinities: string[];
  specs: {
    label: string;
    value: string;
  }[];
  images: string[];
}

export const products: Product[] = [
  {
    id: 1,
    name: "Vòng Tay Thạch Anh Tóc Vàng 12ly",
    price: "4.500.000đ",
    oldPrice: "5.200.000đ",
    tag: "Mệnh Kim / Thổ",
    category: "Vòng tay phong thủy",
    affinities: ["Mệnh Kim", "Mệnh Thổ"],
    img: "https://images.unsplash.com/photo-1615655114865-4cc1bda5901e?q=80&w=1000&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1615655114865-4cc1bda5901e?q=80&w=1000&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1000&auto=format&fit=crop"
    ],
    description: "Thạch anh tóc vàng (Rutilated Quartz) là một trong những loại đá quý phong thủy được ưa chuộng nhất bởi vẻ đẹp lộng lẫy và năng lượng mạnh mẽ. Những sợi 'tóc' vàng bên trong thực chất là các tinh thể rutil, mang lại hiệu ứng ánh kim rực rỡ dưới ánh sáng. Trong phong thủy, màu vàng tượng trưng cho hành Thổ và hành Kim. Do đó, vòng tay thạch anh tóc vàng cực kỳ phù hợp cho những người thuộc hai cung mệnh này. Nó giúp kích hoạt cung tài lộc, mang lại sự quyết đoán trong kinh doanh và bảo vệ chủ nhân khỏi những năng lượng tiêu cực.",
    specs: [
      { label: "Chất liệu", value: "Đá Thạch Anh Tóc Vàng Tự Nhiên" },
      { label: "Kích thước hạt", value: "12mm (12ly)" },
      { label: "Số lượng hạt", value: "17 - 19 hạt (Tùy size tay)" },
      { label: "Hợp mệnh", value: "Mệnh Kim, Mệnh Thổ" },
      { label: "Xuất xứ", value: "Brazil / Madagascar" }
    ]
  },
  {
    id: 2,
    name: "Vòng Tay Trầm Hương Tốc Kiến 108 Hạt",
    price: "2.800.000đ",
    oldPrice: "3.500.000đ",
    tag: "Mọi Cung Mệnh",
    category: "Vòng tay phong thủy",
    affinities: ["Mệnh Kim", "Mệnh Mộc", "Mệnh Thủy", "Mệnh Hỏa", "Mệnh Thổ"],
    img: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1000&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1605100804763-247f67b3557e?q=80&w=1000&auto=format&fit=crop"
    ],
    description: "Vòng tay Trầm Hương 108 hạt mang ý nghĩa đoạn trừ 108 loại phiền não, mang lại sự bình an, thư thái trong tâm hồn. Hương thơm dịu nhẹ của trầm giúp xua đuổi tà khí, thu hút vượng khí và may mắn cho chủ nhân.",
    specs: [
      { label: "Chất liệu", value: "Trầm Hương Tốc Kiến Tự Nhiên" },
      { label: "Số lượng hạt", value: "108 hạt" },
      { label: "Kích thước hạt", value: "6mm" },
      { label: "Hợp mệnh", value: "Tất cả các mệnh" }
    ]
  },
  {
    id: 3,
    name: "Tượng Phật Di Lặc Ngọc Hoàng Long",
    price: "18.500.000đ",
    tag: "Mệnh Thổ / Kim",
    category: "Vật phẩm phong thủy",
    affinities: ["Mệnh Thổ", "Mệnh Kim"],
    img: "https://images.unsplash.com/photo-1544124499-58912cbddaad?q=80&w=1000&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1544124499-58912cbddaad?q=80&w=1000&auto=format&fit=crop"
    ],
    description: "Phật Di Lặc là biểu tượng của niềm vui, hạnh phúc và sự sung túc. Tượng được tạc từ đá Ngọc Hoàng Long tự nhiên với sắc vàng rực rỡ, mang lại năng lượng tích cực và tài lộc cho gia chủ.",
    specs: [
      { label: "Chất liệu", value: "Đá Ngọc Hoàng Long Tự Nhiên" },
      { label: "Kích thước", value: "Cao 20cm, Rộng 15cm" },
      { label: "Hợp mệnh", value: "Mệnh Thổ, Mệnh Kim" }
    ]
  },
  {
    id: 4,
    name: "Quả Cầu Thạch Anh Hồng Tự Nhiên",
    price: "5.200.000đ",
    tag: "Mệnh Hỏa / Thổ",
    category: "Vật phẩm phong thủy",
    affinities: ["Mệnh Hỏa", "Mệnh Thổ"],
    img: "https://images.unsplash.com/photo-1569003339405-ea396a5a8a90?q=80&w=1000&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1569003339405-ea396a5a8a90?q=80&w=1000&auto=format&fit=crop"
    ],
    description: "Thạch anh hồng là viên đá của tình yêu và sự bao dung. Quả cầu thạch anh hồng giúp cân bằng cảm xúc, cải thiện các mối quan hệ và mang lại sự bình an cho không gian sống.",
    specs: [
      { label: "Chất liệu", value: "Đá Thạch Anh Hồng Tự Nhiên" },
      { label: "Đường kính", value: "12cm" },
      { label: "Hợp mệnh", value: "Mệnh Hỏa, Mệnh Thổ" }
    ]
  },
  {
    id: 5,
    name: "Mặt Dây Chuyền Phật Bản Mệnh Thạch Anh Đen",
    price: "1.500.000đ",
    tag: "Mệnh Thủy / Mộc",
    category: "Trang sức phong thủy",
    affinities: ["Mệnh Thủy", "Mệnh Mộc"],
    img: "https://images.unsplash.com/photo-1611085583191-a3b13b24424a?q=80&w=1000&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1611085583191-a3b13b24424a?q=80&w=1000&auto=format&fit=crop"
    ],
    description: "Phật Bản Mệnh giúp bảo hộ, mang lại bình an và may mắn cho mỗi con giáp. Mặt dây chuyền được tạc từ đá thạch anh đen tự nhiên, mang năng lượng bảo vệ mạnh mẽ.",
    specs: [
      { label: "Chất liệu", value: "Đá Thạch Anh Đen Tự Nhiên" },
      { label: "Kích thước", value: "4cm x 2.5cm" },
      { label: "Hợp mệnh", value: "Mệnh Thủy, Mệnh Mộc" }
    ]
  },
  {
    id: 6,
    name: "Tỳ Hưu Cõng Tiền Đá Cẩm Thủy",
    price: "12.000.000đ",
    tag: "Mệnh Mộc / Hỏa",
    category: "Linh vật chiêu tài",
    affinities: ["Mệnh Mộc", "Mệnh Hỏa"],
    img: "https://images.unsplash.com/photo-1590548784585-645d2b60493e?q=80&w=1000&auto=format&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1590548784585-645d2b60493e?q=80&w=1000&auto=format&fit=crop"
    ],
    description: "Tỳ Hưu là linh vật chiêu tài giữ lộc hàng đầu trong phong thủy. Cặp Tỳ Hưu được tạc từ đá cẩm thủy tự nhiên, giúp thu hút tài lộc và bảo vệ của cải cho gia chủ.",
    specs: [
      { label: "Chất liệu", value: "Đá Cẩm Thủy Tự Nhiên" },
      { label: "Kích thước", value: "Dài 15cm" },
      { label: "Hợp mệnh", value: "Mệnh Mộc, Mệnh Hỏa" }
    ]
  }
];
