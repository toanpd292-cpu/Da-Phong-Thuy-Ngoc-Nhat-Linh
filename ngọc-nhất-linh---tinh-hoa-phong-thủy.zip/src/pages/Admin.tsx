import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Trash2, Edit2, Save, X, LayoutDashboard, ShoppingBag, BookOpen, Users, Image as ImageIcon, Check, AlertCircle, Sparkles, Wand2, Loader2 } from 'lucide-react';
import { supabaseService, Blog, Customer, CampaignImage } from '../services/supabaseService';
import { Product } from '../data/products';
import { GoogleGenAI } from "@google/genai";

type Tab = 'products' | 'blogs' | 'customers' | 'campaigns';

export default function Admin() {
  const [activeTab, setActiveTab] = useState<Tab>('products');
  const [products, setProducts] = useState<Product[]>([]);
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [campaigns, setCampaigns] = useState<CampaignImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [formData, setFormData] = useState<any>({});
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generationPrompt, setGenerationPrompt] = useState('');
  const [isGenerationModalOpen, setIsGenerationModalOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'products') {
        const data = await supabaseService.getProducts();
        setProducts(data);
      } else if (activeTab === 'blogs') {
        const data = await supabaseService.getBlogs();
        setBlogs(data);
      } else if (activeTab === 'customers') {
        const data = await supabaseService.getCustomers();
        setCustomers(data);
      } else if (activeTab === 'campaigns') {
        const data = await supabaseService.getAllCampaignImages();
        setCampaigns(data);
      }
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (item: any = null) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      // Default values for new items
      if (activeTab === 'products') {
        setFormData({ name: '', price: '', tag: '', category: '', img: '', description: '' });
      } else if (activeTab === 'blogs') {
        setFormData({ title: '', content: '', author: '', date: new Date().toISOString().split('T')[0], image: '', category: '', excerpt: '' });
      } else if (activeTab === 'campaigns') {
        setFormData({ url: '', title: '', subtitle: '', active: true });
      }
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingItem(null);
    setFormData({});
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData({ ...formData, [name]: val });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (activeTab === 'products') {
        if (editingItem) {
          await supabaseService.updateProduct(editingItem.id, formData);
        } else {
          await supabaseService.addProduct(formData);
        }
      } else if (activeTab === 'blogs') {
        if (editingItem) {
          await supabaseService.updateBlog(editingItem.id, formData);
        } else {
          await supabaseService.addBlog(formData);
        }
      } else if (activeTab === 'campaigns') {
        if (editingItem) {
          await supabaseService.updateCampaignImage(editingItem.id, formData);
        } else {
          await supabaseService.addCampaignImage(formData);
        }
      }
      fetchData();
      handleCloseModal();
    } catch (err) {
      console.error('Error saving data:', err);
      alert('Có lỗi xảy ra khi lưu dữ liệu. Vui lòng kiểm tra lại cấu hình Supabase.');
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa mục này?')) return;
    try {
      if (activeTab === 'products') await supabaseService.deleteProduct(id);
      else if (activeTab === 'blogs') await supabaseService.deleteBlog(id);
      else if (activeTab === 'campaigns') await supabaseService.deleteCampaignImage(id);
      fetchData();
    } catch (err) {
      console.error('Error deleting data:', err);
    }
  };

  const handleGenerateImage = async () => {
    if (!generationPrompt.trim()) {
      alert('Vui lòng nhập mô tả hình ảnh');
      return;
    }

    setIsGeneratingImage(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [{ parts: [{ text: generationPrompt }] }],
        config: {
          imageConfig: {
            aspectRatio: "16:9"
          }
        }
      });

      let imageUrl = '';
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        setFormData({ ...formData, url: imageUrl });
        setIsGenerationModalOpen(false);
        setGenerationPrompt('');
        if (!isModalOpen) {
          handleOpenModal({ ...formData, url: imageUrl });
        }
      } else {
        alert('Không thể tạo hình ảnh. Vui lòng thử lại.');
      }
    } catch (err) {
      console.error('Error generating image:', err);
      alert('Lỗi khi tạo hình ảnh: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsGeneratingImage(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="w-full lg:w-64 space-y-2">
            <button 
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center gap-3 px-6 py-4 rounded-xl font-bold transition-all ${activeTab === 'products' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            >
              <ShoppingBag className="w-5 h-5" /> Sản phẩm
            </button>
            <button 
              onClick={() => setActiveTab('blogs')}
              className={`w-full flex items-center gap-3 px-6 py-4 rounded-xl font-bold transition-all ${activeTab === 'blogs' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            >
              <BookOpen className="w-5 h-5" /> Bài viết
            </button>
            <button 
              onClick={() => setActiveTab('customers')}
              className={`w-full flex items-center gap-3 px-6 py-4 rounded-xl font-bold transition-all ${activeTab === 'customers' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            >
              <Users className="w-5 h-5" /> Khách hàng
            </button>
            <button 
              onClick={() => setActiveTab('campaigns')}
              className={`w-full flex items-center gap-3 px-6 py-4 rounded-xl font-bold transition-all ${activeTab === 'campaigns' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            >
              <ImageIcon className="w-5 h-5" /> Chiến dịch
            </button>
          </aside>

          {/* Main Content */}
          <main className="flex-1 bg-white rounded-3xl shadow-sm border border-slate-100 p-8 overflow-hidden">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-serif font-bold uppercase tracking-wider">
                Quản lý {activeTab === 'products' ? 'Sản phẩm' : activeTab === 'blogs' ? 'Bài viết' : activeTab === 'customers' ? 'Khách hàng' : 'Chiến dịch'}
              </h2>
              <div className="flex items-center gap-3">
                {activeTab === 'campaigns' && (
                  <button 
                    onClick={() => setIsGenerationModalOpen(true)}
                    className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold text-sm flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
                  >
                    <Sparkles className="w-4 h-4" /> Tạo ảnh AI
                  </button>
                )}
                {activeTab !== 'customers' && (
                  <button 
                    onClick={() => handleOpenModal()}
                    className="bg-charcoal text-white px-6 py-2 rounded-lg font-bold text-sm flex items-center gap-2 hover:bg-primary transition-all"
                  >
                    <Plus className="w-4 h-4" /> Thêm mới
                  </button>
                )}
              </div>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="border-b border-slate-100">
                      <th className="py-4 px-4 text-xs font-bold uppercase tracking-widest text-slate-400">Thông tin</th>
                      <th className="py-4 px-4 text-xs font-bold uppercase tracking-widest text-slate-400">Chi tiết</th>
                      <th className="py-4 px-4 text-xs font-bold uppercase tracking-widest text-slate-400 text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeTab === 'products' && products.map(p => (
                      <tr key={p.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-4">
                            <img src={p.img} alt={p.name} className="w-12 h-12 rounded-lg object-cover bg-slate-100" />
                            <div>
                              <p className="font-bold text-sm">{p.name}</p>
                              <p className="text-xs text-slate-400">{p.category}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <p className="font-bold text-primary">{p.price}</p>
                          <p className="text-xs text-slate-400">{p.tag}</p>
                        </td>
                        <td className="py-4 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button onClick={() => handleOpenModal(p)} className="p-2 text-slate-400 hover:text-primary transition-colors"><Edit2 className="w-4 h-4" /></button>
                            <button onClick={() => handleDelete(p.id)} className="p-2 text-slate-400 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {activeTab === 'blogs' && blogs.map(b => (
                      <tr key={b.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-4">
                            <img src={b.image} alt={b.title} className="w-12 h-12 rounded-lg object-cover bg-slate-100" />
                            <div>
                              <p className="font-bold text-sm">{b.title}</p>
                              <p className="text-xs text-slate-400">{b.author} • {b.date}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <p className="text-xs text-slate-500 line-clamp-2">{b.excerpt}</p>
                        </td>
                        <td className="py-4 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button onClick={() => handleOpenModal(b)} className="p-2 text-slate-400 hover:text-primary transition-colors"><Edit2 className="w-4 h-4" /></button>
                            <button onClick={() => handleDelete(b.id!)} className="p-2 text-slate-400 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {activeTab === 'customers' && customers.map(c => (
                      <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 px-4">
                          <div>
                            <p className="font-bold text-sm">{c.name}</p>
                            <p className="text-xs text-slate-400">{c.email}</p>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <p className="text-sm">{c.phone}</p>
                          <p className="text-xs text-slate-400">{c.address}</p>
                        </td>
                        <td className="py-4 px-4 text-right">
                          <button className="p-2 text-slate-400 hover:text-primary transition-colors"><Edit2 className="w-4 h-4" /></button>
                        </td>
                      </tr>
                    ))}
                    {activeTab === 'campaigns' && campaigns.map(c => (
                      <tr key={c.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-4">
                            <img src={c.url} alt={c.title} className="w-12 h-12 rounded-lg object-cover bg-slate-100" />
                            <div>
                              <p className="font-bold text-sm">{c.title}</p>
                              <p className="text-xs text-slate-400">{c.subtitle}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4">
                          <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${c.active ? 'bg-green-100 text-green-600' : 'bg-slate-100 text-slate-400'}`}>
                            {c.active ? 'Đang chạy' : 'Tạm dừng'}
                          </span>
                        </td>
                        <td className="py-4 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button onClick={() => handleOpenModal(c)} className="p-2 text-slate-400 hover:text-primary transition-colors"><Edit2 className="w-4 h-4" /></button>
                            <button onClick={() => handleDelete(c.id!)} className="p-2 text-slate-400 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleCloseModal}
              className="absolute inset-0 bg-charcoal/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-serif font-bold">
                  {editingItem ? 'Chỉnh sửa' : 'Thêm mới'} {activeTab === 'products' ? 'Sản phẩm' : activeTab === 'blogs' ? 'Bài viết' : 'Chiến dịch'}
                </h3>
                <button onClick={handleCloseModal} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <form onSubmit={handleSubmit} className="p-8 overflow-y-auto space-y-6">
                {activeTab === 'products' && (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Tên sản phẩm</label>
                        <input name="name" value={formData.name || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Giá</label>
                        <input name="price" value={formData.price || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" placeholder="1.500.000 VNĐ" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Danh mục</label>
                        <input name="category" value={formData.category || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Nhãn (Tag)</label>
                        <input name="tag" value={formData.tag || ''} onChange={handleInputChange} className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Link hình ảnh</label>
                      <input name="img" value={formData.img || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Mô tả</label>
                      <textarea name="description" value={formData.description || ''} onChange={handleInputChange} rows={4} className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all resize-none" />
                    </div>
                  </>
                )}

                {activeTab === 'blogs' && (
                  <>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Tiêu đề</label>
                      <input name="title" value={formData.title || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Tác giả</label>
                        <input name="author" value={formData.author || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Ngày đăng</label>
                        <input name="date" type="date" value={formData.date || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Link hình ảnh</label>
                      <input name="image" value={formData.image || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Tóm tắt</label>
                      <textarea name="excerpt" value={formData.excerpt || ''} onChange={handleInputChange} rows={2} className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all resize-none" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Nội dung</label>
                      <textarea name="content" value={formData.content || ''} onChange={handleInputChange} rows={6} className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all resize-none" />
                    </div>
                  </>
                )}

                {activeTab === 'campaigns' && (
                  <>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Tiêu đề chính</label>
                      <input name="title" value={formData.title || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Tiêu đề phụ</label>
                      <input name="subtitle" value={formData.subtitle || ''} onChange={handleInputChange} required className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Link hình ảnh nền</label>
                      <div className="flex gap-2">
                        <input name="url" value={formData.url || ''} onChange={handleInputChange} required className="flex-1 px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all" placeholder="https://..." />
                        <button 
                          type="button"
                          onClick={() => setIsGenerationModalOpen(true)}
                          className="px-4 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-100 transition-colors flex items-center gap-2 text-xs font-bold"
                          title="Tạo ảnh bằng AI"
                        >
                          <Wand2 className="w-4 h-4" /> AI
                        </button>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="checkbox" 
                        id="active" 
                        name="active" 
                        checked={formData.active || false} 
                        onChange={handleInputChange}
                        className="w-5 h-5 rounded border-slate-300 text-primary focus:ring-primary"
                      />
                      <label htmlFor="active" className="text-sm font-medium text-slate-600">Kích hoạt hiển thị trên trang chủ</label>
                    </div>
                  </>
                )}

                <div className="pt-4 flex gap-4">
                  <button type="button" onClick={handleCloseModal} className="flex-1 px-6 py-4 rounded-xl font-bold uppercase tracking-widest text-slate-600 bg-slate-100 hover:bg-slate-200 transition-all">
                    Hủy
                  </button>
                  <button type="submit" className="flex-1 px-6 py-4 rounded-xl font-bold uppercase tracking-widest text-white bg-primary hover:bg-primary-dark shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2">
                    <Save className="w-5 h-5" /> Lưu thay đổi
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* AI Generation Modal */}
      <AnimatePresence>
        {isGenerationModalOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isGeneratingImage && setIsGenerationModalOpen(false)}
              className="absolute inset-0 bg-charcoal/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden p-8"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <Sparkles className="w-6 h-6 text-indigo-600" />
                  </div>
                  <h3 className="text-xl font-serif font-bold">Tạo hình ảnh bằng AI</h3>
                </div>
                <button 
                  onClick={() => setIsGenerationModalOpen(false)}
                  disabled={isGeneratingImage}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors disabled:opacity-50"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Mô tả hình ảnh (Prompt)</label>
                  <textarea 
                    value={generationPrompt}
                    onChange={(e) => setGenerationPrompt(e.target.value)}
                    placeholder="Ví dụ: Một chiếc vòng tay ngọc trai sang trọng trên nền lụa trắng, ánh sáng dịu nhẹ..."
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-primary focus:ring-0 outline-none transition-all resize-none"
                  />
                </div>

                <div className="bg-indigo-50 p-4 rounded-xl flex gap-3">
                  <AlertCircle className="w-5 h-5 text-indigo-600 shrink-0" />
                  <p className="text-xs text-indigo-700 leading-relaxed">
                    AI sẽ tạo ra một hình ảnh banner chất lượng cao (16:9) dựa trên mô tả của bạn. Quá trình này có thể mất vài giây.
                  </p>
                </div>

                <button 
                  onClick={handleGenerateImage}
                  disabled={isGeneratingImage || !generationPrompt.trim()}
                  className="w-full py-4 rounded-xl font-bold uppercase tracking-widest text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGeneratingImage ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" /> Đang tạo ảnh...
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-4 h-4" /> Bắt đầu tạo
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
