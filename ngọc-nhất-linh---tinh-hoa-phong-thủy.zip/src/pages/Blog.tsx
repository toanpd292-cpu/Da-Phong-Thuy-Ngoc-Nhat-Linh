import React, { useState, useEffect } from 'react';
import { Calendar, Clock, User, ChevronRight, Mail, Send, Loader2, Bookmark, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { supabaseService, Blog as BlogType } from '../services/supabaseService';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const BlogSkeleton = () => (
  <div className="bg-white rounded-2xl overflow-hidden border border-slate-100 animate-pulse">
    <div className="aspect-[16/9] bg-slate-200"></div>
    <div className="p-6 space-y-4">
      <div className="h-4 bg-slate-200 rounded w-1/4"></div>
      <div className="h-6 bg-slate-200 rounded w-3/4"></div>
      <div className="h-4 bg-slate-200 rounded w-full"></div>
      <div className="h-4 bg-slate-200 rounded w-2/3"></div>
    </div>
  </div>
);

export default function Blog() {
  const [blogs, setBlogs] = useState<BlogType[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const data = await supabaseService.getBlogs();
        setBlogs(data);
      } catch (err) {
        console.error('Error fetching blogs:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchBlogs();
  }, []);

  const categories = ['Tất cả', ...Array.from(new Set(blogs.map(b => b.category)))];

  const filteredBlogs = blogs.filter(blog => {
    const matchesCategory = selectedCategory === 'Tất cả' || blog.category === selectedCategory;
    const matchesSearch = blog.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         blog.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    setSubmitting(true);
    setError('');
    try {
      await supabaseService.subscribeNewsletter(email);
      setSubscribed(true);
      setEmail('');
    } catch (err) {
      console.error('Newsletter error:', err);
      setError('Có lỗi xảy ra. Vui lòng thử lại sau.');
    } finally {
      setSubmitting(false);
    }
  };

  const featuredBlog = filteredBlogs[0];
  const otherBlogs = filteredBlogs.slice(1);

  return (
    <div className="bg-white min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 bg-slate-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1588345921523-c2dcd5702dbe?q=80&w=2070&auto=format&fit=crop" 
            className="w-full h-full object-cover"
            alt="Background"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-900/50 to-slate-900"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="inline-block px-4 py-1.5 bg-primary/20 text-primary text-xs font-bold uppercase tracking-[0.3em] rounded-full mb-6 border border-primary/30">
              Kiến Thức & Chia Sẻ
            </span>
            <h1 className="font-serif text-4xl md:text-6xl font-bold text-white mb-6">Blog Phong Thủy</h1>
            <p className="max-w-2xl mx-auto text-slate-300 text-lg leading-relaxed">
              Khám phá thế giới đá quý, nghệ thuật phong thủy và những câu chuyện tâm linh giúp cân bằng cuộc sống.
            </p>
          </motion.div>
        </div>
      </section>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Filter & Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-16">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 w-full md:w-auto no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  "px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-widest transition-all whitespace-nowrap border",
                  selectedCategory === cat 
                    ? "bg-primary text-white border-primary shadow-lg shadow-primary/20" 
                    : "bg-white text-slate-500 border-slate-200 hover:border-primary/50 hover:text-primary"
                )}
              >
                {cat}
              </button>
            ))}
          </div>
          
          <div className="relative w-full md:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input 
              type="text"
              placeholder="Tìm kiếm bài viết..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl focus:bg-white focus:border-primary focus:ring-4 focus:ring-primary/5 outline-none transition-all text-sm"
            />
          </div>
        </div>

        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-sm text-slate-500 mb-12">
          <a href="/" className="hover:text-primary transition-colors">Trang chủ</a>
          <ChevronRight className="w-4 h-4" />
          <span className="text-slate-900 font-medium">Blog</span>
        </nav>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => <BlogSkeleton key={i} />)}
          </div>
        ) : filteredBlogs.length > 0 ? (
          <div className="space-y-20">
            {/* Featured Post */}
            {featuredBlog && !searchQuery && selectedCategory === 'Tất cả' && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="group relative grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-50 rounded-3xl overflow-hidden p-4 lg:p-8 border border-slate-100"
              >
                <div className="lg:col-span-7 aspect-[16/9] lg:aspect-auto lg:h-[450px] rounded-2xl overflow-hidden">
                  <img 
                    src={featuredBlog.image} 
                    alt={featuredBlog.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="lg:col-span-5 space-y-6 lg:px-6">
                  <div className="flex items-center gap-4">
                    <span className="px-3 py-1 bg-primary text-white text-[10px] font-bold uppercase tracking-widest rounded">
                      {featuredBlog.category}
                    </span>
                    <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(featuredBlog.date).toLocaleDateString('vi-VN')}
                    </span>
                  </div>
                  <h2 className="text-3xl lg:text-4xl font-serif font-bold text-charcoal leading-tight group-hover:text-primary transition-colors">
                    {featuredBlog.title}
                  </h2>
                  <p className="text-slate-600 leading-relaxed line-clamp-3">
                    {featuredBlog.excerpt}
                  </p>
                  <div className="flex items-center gap-3 pt-4">
                    <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">
                      <User className="w-5 h-5 text-slate-500" />
                    </div>
                    <div>
                      <p className="text-sm font-bold">{featuredBlog.author}</p>
                      <p className="text-[10px] text-primary font-medium uppercase tracking-widest">Tác giả</p>
                    </div>
                  </div>
                  <button className="flex items-center gap-2 text-primary font-bold uppercase tracking-widest text-xs group/btn">
                    Đọc tiếp 
                    <ChevronRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* Other Posts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {otherBlogs.map((blog, idx) => (
                <motion.article 
                  key={blog.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="group flex flex-col bg-white rounded-2xl overflow-hidden border border-slate-100 hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300"
                >
                  <div className="aspect-[16/10] overflow-hidden relative">
                    <img 
                      src={blog.image} 
                      alt={blog.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-charcoal text-[10px] font-bold uppercase tracking-widest rounded shadow-sm">
                        {blog.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <div className="flex items-center gap-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(blog.date).toLocaleDateString('vi-VN')}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        5 phút đọc
                      </span>
                    </div>
                    <h3 className="text-xl font-serif font-bold text-charcoal mb-4 line-clamp-2 group-hover:text-primary transition-colors">
                      {blog.title}
                    </h3>
                    <p className="text-slate-500 text-sm leading-relaxed line-clamp-3 mb-6 flex-1">
                      {blog.excerpt}
                    </p>
                    <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center">
                          <User className="w-3 h-3 text-slate-400" />
                        </div>
                        <span className="text-xs font-medium text-slate-600">{blog.author}</span>
                      </div>
                      <button className="text-primary">
                        <Bookmark className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>

            {/* Newsletter Section */}
            <section className="relative rounded-[2.5rem] bg-charcoal p-8 md:p-16 overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-[100px] -mr-32 -mt-32"></div>
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-primary/10 rounded-full blur-[100px] -ml-32 -mb-32"></div>
              
              <div className="relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-full text-primary text-xs font-bold uppercase tracking-widest">
                    <Mail className="w-4 h-4" />
                    Bản tin Ngọc Nhất Linh
                  </div>
                  <h2 className="text-3xl md:text-5xl font-serif font-bold text-white leading-tight">
                    Nhận Kiến Thức Phong Thủy <br /> <span className="text-primary italic">Mỗi Tuần</span>
                  </h2>
                  <p className="text-slate-400 text-lg max-w-lg">
                    Đăng ký để nhận những bài viết chuyên sâu về đá quý, mẹo phong thủy và ưu đãi sớm nhất từ chúng tôi.
                  </p>
                </div>

                <div className="bg-white/5 backdrop-blur-md p-8 rounded-3xl border border-white/10">
                  {subscribed ? (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="text-center py-8"
                    >
                      <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
                        <Send className="text-primary w-8 h-8" />
                      </div>
                      <h3 className="text-2xl font-serif font-bold text-white mb-2">Cảm ơn bạn đã đăng ký!</h3>
                      <p className="text-slate-400">Chúng tôi sẽ gửi những thông tin hữu ích nhất đến bạn sớm.</p>
                      <button 
                        onClick={() => setSubscribed(false)}
                        className="mt-6 text-primary font-bold text-sm uppercase tracking-widest hover:underline"
                      >
                        Đăng ký với email khác
                      </button>
                    </motion.div>
                  ) : (
                    <form onSubmit={handleSubscribe} className="space-y-4">
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                        <input 
                          type="email" 
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="Nhập địa chỉ email của bạn..."
                          className="w-full pl-12 pr-4 py-4 bg-white/10 border border-white/20 rounded-2xl text-white placeholder:text-slate-500 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                      <button 
                        type="submit"
                        disabled={submitting}
                        className="w-full bg-primary hover:bg-primary-dark text-white py-4 rounded-2xl font-bold uppercase tracking-widest shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {submitting ? (
                          <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                          <>
                            Đăng ký ngay
                            <Send className="w-4 h-4" />
                          </>
                        )}
                      </button>
                      {error && <p className="text-red-400 text-xs text-center mt-2">{error}</p>}
                      <p className="text-[10px] text-slate-500 text-center uppercase tracking-widest mt-4">
                        * Chúng tôi cam kết bảo mật thông tin của bạn.
                      </p>
                    </form>
                  )}
                </div>
              </div>
            </section>
          </div>
        ) : (
          <div className="py-20 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-50 mb-6">
              <Bookmark className="w-10 h-10 text-slate-300" />
            </div>
            <h3 className="text-2xl font-serif font-bold text-charcoal mb-2">Không tìm thấy bài viết</h3>
            <p className="text-slate-500">Vui lòng thử điều chỉnh bộ lọc hoặc từ khóa tìm kiếm của bạn.</p>
            <button 
              onClick={() => {
                setSelectedCategory('Tất cả');
                setSearchQuery('');
              }}
              className="mt-8 text-primary font-bold uppercase tracking-widest text-xs hover:underline"
            >
              Xem tất cả bài viết
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
